package com.example.demologin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
