class ApiEndpoints{
  static const String baseurl='https://dummyjson.com/auth/';
  static const String login='login';
  static const String state="https://uatapp.manappuram.net/BussinessAssoApi/api/BA/GetBA_Data/GETSTATELIST/0";
  static const String district ="https://uatapp.manappuram.net/BussinessAssoApi/api/BA/GetBA_Data/GETDISTRICTLIST/";
}