
import 'dart:ui';

class AppColor{
  static const appColormain =Color(0xFFD9D9D9);
  static const appColor2=Color(0xFFFFFFFF);
}