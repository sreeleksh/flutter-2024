import 'dart:convert';

import 'package:demologin/cors/helpers/api.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../model/DistrictModel.dart';
import '../model/Loginmodel.dart';
import '../model/StateModel.dart';
//import 'package:http/http.dart' as http;

class LoginController extends GetxController {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  var passwordVisible = false.obs;
  void updateVisbility() {
    passwordVisible.toggle();
  }

  var loading = false.obs;

  var loginModel = LoginModel().obs;
  Future<void> userLoginApi() async {
    var apiurl = ApiEndpoints.baseurl + ApiEndpoints.login;
    final headers = {'Content-Type': 'application/json'};
    final requestData = {
      "username": email.text.trim(),
      "password": password.text.trim()
    };
    final jsonBody = json.encode(requestData);
    try {
      loading.value = true;
      final response = await http.post(
        Uri.parse(apiurl),
        headers: headers,
        body: jsonBody,
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        loginModel(LoginModel.fromJson(responseData));
        Fluttertoast.showToast(msg: "Login true");
      } else if (response.statusCode == 400) {
        final responseData = json.decode(response.body);
        loginModel(LoginModel.fromJson(responseData));
        Fluttertoast.showToast(msg: "Login false");
      } else {
        throw Exception('Request failed with status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    } finally {
      loading.value = false;
    }
  }

  //fetch state
  var stateList = <StateModel>[].obs;
  var stateId=''.obs;
  var currentState=''.obs;
  var stateModel = StateModel().obs;
  Future<void> fetchStateApi() async {
    var apiurl = ApiEndpoints.state;
    final headers = {'Content-Type': 'application/json'};
    try {
      loading.value = true;
      final response = await http.get(
        Uri.parse(apiurl),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final List<dynamic> responseData = json.decode(response.body);
        stateList.value = responseData
            .map((element) => stateModel(StateModel.fromJson(element)))
            .toList();
        Fluttertoast.showToast(msg: "true");
      } else if (response.statusCode == 400) {
        final responseData = json.decode(response.body);
        loginModel(LoginModel.fromJson(responseData));
        Fluttertoast.showToast(msg: "False");
      } else {
        throw Exception('Request failed with status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    } finally {
      loading.value = false;
    }
  }

  //fetch state
  var districtList = <DistrictModel>[].obs;
  var districtModel = DistrictModel().obs;
  var districtId=''.obs;
  var currentDistrict=''.obs;
  Future<void> fetchDistrictApi({required String stateId}) async {
    var apiurl = ApiEndpoints.district+stateId;
    final headers = {'Content-Type': 'application/json'};
    try {
      loading.value = true;
      final response = await http.get(
        Uri.parse(apiurl),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final List<dynamic> responseData = json.decode(response.body);
        print(response.body);
        districtList.value = responseData
            .map((element) => districtModel(DistrictModel.fromJson(element)))
            .toList();
        Fluttertoast.showToast(msg: "true");
      } else if (response.statusCode == 400) {
        final responseData = json.decode(response.body);
        loginModel(LoginModel.fromJson(responseData));
        Fluttertoast.showToast(msg: "False");
      } else {
        throw Exception('Request failed with status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    } finally {
      loading.value = false;
    }
  }
}
