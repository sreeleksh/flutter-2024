import 'package:demologin/cors/utils/configs/styles/colors.dart';
import 'package:demologin/features/auth/login/controller/controller.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:http/http.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _loginController.fetchStateApi();
  }

  final LoginController _loginController = Get.put(LoginController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: Get.height,
          width: Get.width,
          color: AppColor.appColormain,
          child: Padding(
            padding: const EdgeInsets.only(
                top: 109, bottom: 110, right: 50, left: 50),
            child: Container(
                decoration: BoxDecoration(
                  color: Colors.amber,
                  border: Border.all(
                    width: 2,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),

                // height: 109,
                child: ListView(
                  scrollDirection: Axis.vertical,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 50, horizontal: 15),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Hello",
                            style: TextStyle(color: Colors.black, fontSize: 15),
                          ),
                          Text(
                            "Welcome Back",
                            style:
                                TextStyle(color: Colors.black12, fontSize: 15),
                          ),
                          TextFormField(
                            controller: _loginController.email,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide:
                                    const BorderSide(color: Color(0xffd9d9d9)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide:
                                    const BorderSide(color: Color(0xffd9d9d9)),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: const BorderSide(color: Colors.red),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              labelText: 'email',
                              hintText: 'Enter Your Email',
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Obx(
                            () => TextFormField(
                              controller: _loginController.password,
                              keyboardType: TextInputType.visiblePassword,
                              obscureText:
                                  _loginController.passwordVisible.value,
                              decoration: InputDecoration(
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: const BorderSide(
                                      color: Color(0xffd9d9d9)),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: const BorderSide(
                                      color: Color(0xffd9d9d9)),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide:
                                      const BorderSide(color: Colors.red),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                labelText: 'password',
                                hintText: 'Enter Your password',
                                suffixIcon: IconButton(
                                  onPressed: () {
                                    _loginController.updateVisbility();
                                  },
                                  icon: Icon(
                                      _loginController.passwordVisible.value
                                          ? Icons.visibility_off
                                          : Icons.visibility),
                                  color: Colors.black12,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Text(
                            "State",
                            style: TextStyle(
                                color: AppColor.appColor2,
                                fontFamily: "ralewayRegular",
                                fontSize: 12),
                          ),
                          Obx(
                            () => Container(
                              width: Get.width,
                              decoration: BoxDecoration(
                                color: const Color(0xfff5f5f5),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                  hintStyle: TextStyle(
                                    fontSize: 16,
                                    fontFamily: "poppinsRegular",
                                    color: Colors.black,
                                  ),
                                  fillColor: const Color(0xfff5f5f5),
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: 16.5, horizontal: 15),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                        color: Color(0xffd9d9d9)),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                        color: Color(0xffd9d9d9)),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide:
                                        const BorderSide(color: Colors.red),
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                ),
                                hint: Text(
                                  'Select a state',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: "poppinsRegular",
                                    color: Colors.black,
                                  ),
                                ),
                                value: _loginController.stateId.value.isEmpty
                                    ? null
                                    : _loginController.stateId.value,
                                items:
                                    _loginController.stateList.map((element) {
                                  return DropdownMenuItem(
                                      value: element.iD.toString(),
                                      child: Text(element.sTATE ?? ''));
                                }).toList(),
                                onChanged: (value) {
                                  _loginController.stateId.value =
                                      value.toString();
                                  _onStateSelected(
                                      _loginController.stateId.value);
                                },
                              ),
                            ),
                          ),
                          Text(
                            "District",
                            style: TextStyle(
                                color: AppColor.appColor2,
                                fontFamily: "ralewayRegular",
                                fontSize: 12),
                          ),
                          Obx(
                            () => InkWell(
                              onTap: () {
                                if (_loginController.districtList.isEmpty) {
                                  Fluttertoast.showToast(
                                      msg: "Please enter district");
                                }
                              },
                              child: Container(
                                width: Get.width,
                                decoration: BoxDecoration(
                                  color: const Color(0xfff5f5f5),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: DropdownButtonFormField(
                                  isExpanded: true,
                                  decoration: InputDecoration(
                                    hintStyle: TextStyle(
                                      fontSize: 16,
                                      fontFamily: "poppinsRegular",
                                      color: Colors.black,
                                    ),
                                    fillColor: const Color(0xfff5f5f5),
                                    contentPadding: EdgeInsets.symmetric(
                                        vertical: 16.5, horizontal: 15),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      borderSide: const BorderSide(
                                          color: Color(0xffd9d9d9)),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      borderSide: const BorderSide(
                                          color: Color(0xffd9d9d9)),
                                    ),
                                    errorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                      borderSide:
                                          const BorderSide(color: Colors.red),
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                  ),
                                  hint: Text(
                                    'Select a district',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontFamily: "poppinsRegular",
                                      color: Colors.black,
                                    ),
                                  ),
                                  value:
                                      _loginController.districtId.value.isEmpty
                                          ? null
                                          : _loginController.districtId.value,
                                  items: _loginController.districtList
                                      .map((element) {
                                    return DropdownMenuItem(
                                        value: element.iD.toString(),
                                        child:
                                            Text(element.dISTRICTNAME ?? ''));
                                  }).toList(),
                                  onChanged: (value) {
                                    _loginController.districtId.value =
                                        value.toString();
                                  },
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          ElevatedButton(
                              onPressed: () {
                                if (_loginController.email.text.isEmpty) {
                                  Fluttertoast.showToast(
                                      backgroundColor: Colors.redAccent,
                                      gravity: ToastGravity.SNACKBAR,
                                      msg: "please enter email");
                                } else if (_loginController
                                    .password.text.isEmpty) {
                                  Fluttertoast.showToast(
                                      backgroundColor: Colors.redAccent,
                                      gravity: ToastGravity.SNACKBAR,
                                      msg: "please enter password");
                                } else {
                                  _loginController.userLoginApi();
                                }
                              },
                              child: Text("Login"))
                        ],
                      ),
                    ),
                  ],
                )

                //color:AppColor.appColor2 ,
                ),
          ),
        ),
      ),
    );
  }

  void _onStateSelected(String stateId) {
    if (stateId.isNotEmpty) {
      _loginController.fetchDistrictApi(
          stateId: _loginController.stateId.value);
    }
    _loginController.districtId.value = '';
  }
}
